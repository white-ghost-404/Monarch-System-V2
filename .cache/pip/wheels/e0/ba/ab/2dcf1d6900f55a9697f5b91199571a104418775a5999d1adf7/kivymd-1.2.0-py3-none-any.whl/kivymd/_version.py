# THIS FILE IS GENERATED FROM KIVYMD SETUP.PY
__version__ = '1.2.0'
__hash__ = 'Unknown'
__short_hash__ = 'Unknown'
__date__ = '2026-02-11'
